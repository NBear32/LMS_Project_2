﻿import React from 'react';

export function AdminSubMenu3() {
  return <div>SubMenu 3 Content</div>;
};

export default AdminSubMenu3;