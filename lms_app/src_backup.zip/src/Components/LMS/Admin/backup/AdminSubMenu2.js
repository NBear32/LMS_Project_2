﻿import React from 'react';

export function AdminSubMenu2() {
  return <div>SubMenu 2 Content</div>;
};

export default AdminSubMenu2;