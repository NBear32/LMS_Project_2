

export function Events() {









    
    return (
        <>
            <h1>이벤트 페이지</h1>
        </>
    );
}